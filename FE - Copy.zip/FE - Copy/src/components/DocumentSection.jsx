/* eslint-disable no-unused-vars */
import React from "react";
import {
  FileTextIcon,
  DownloadIcon,
  BookOpenIcon,
  // Không cần import các icon category ở đây nếu chúng được truyền qua documentCategories
  // HeartPulseIcon, ClipboardListIcon, SyringeIcon,
} from "lucide-react";
import documentCategories from "../data/documentCatagories"; // Đảm bảo đường dẫn đúng
import { useNavigate } from "react-router-dom";

export function DocumentsSection() {
  const navigate = useNavigate();

  // Hàm xử lý khi bấm vào tên tài liệu để xem chi tiết
  const handleDocumentClick = (docId) => {
    navigate(`/documents/${docId}`); // Điều hướng đến route chi tiết tài liệu
  };
  return (
    <section id="documents" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Tài liệu sức khỏe học đường
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Tổng hợp các tài liệu, hướng dẫn và biểu mẫu cần thiết cho việc chăm
            sóc sức khỏe học sinh
          </p>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {documentCategories.map((category, index) => (
            <div key={index} className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center mb-6">
                <div
                  className={`inline-flex p-3 rounded-lg ${category.color} mr-4`}
                >
                  {/* Render icon từ category.icon */}
                  <category.icon className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">
                  {category.title}
                </h3>
              </div>
              <div className="space-y-4">
                {category.documents.map((doc, docIndex) => (
                  <div
                    key={docIndex}
                    className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start">
                        <FileTextIcon className="h-5 w-5 text-gray-400 mt-0.5 mr-3" />
                        <div
                          className="cursor-pointer" // Thêm cursor-pointer để người dùng biết là có thể bấm
                          onClick={() => handleDocumentClick(doc.id)} // Gọi hàm điều hướng
                        >
                          <h4 className="font-medium text-gray-900 mb-1 hover:text-blue-600 transition-colors">
                            {doc.name}
                          </h4>
                          <div className="flex items-center text-sm text-gray-500 space-x-4">
                            <span>{doc.size}</span>
                            <span>•</span>
                            <span>{doc.downloads} lượt tải</span>
                          </div>
                        </div>
                      </div>
                      {/* Nút "Tải về" riêng biệt */}
                      <a
                        href={doc.filePath} // Sử dụng filePath từ dữ liệu
                        download
                        className="flex items-center text-blue-600 hover:text-blue-700 text-sm font-medium"
                        onClick={(e) => e.stopPropagation()} // Ngăn chặn sự kiện click lan truyền lên div cha
                      >
                        <DownloadIcon className="h-4 w-4 mr-1" />
                        Tải về
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
        {/* Additional Resources */}
        <div className="mt-16 bg-blue-600 rounded-2xl p-8 text-white text-center">
          <BookOpenIcon className="h-16 w-16 mx-auto mb-4 text-blue-200" />
          <h3 className="text-2xl font-bold mb-4">Cần hỗ trợ thêm?</h3>
          <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
            Nếu bạn không tìm thấy tài liệu cần thiết hoặc cần hỗ trợ thêm, vui
            lòng liên hệ với phòng y tế nhà trường
          </p>
          <button className="bg-white text-blue-600 px-6 py-3 rounded-lg font-medium hover:bg-blue-50 transition-colors">
            Liên hệ phòng y tế
          </button>
        </div>
      </div>
    </section>
  );
}
