import React from "react";

export default function RegisterPage() {
  return <div>RegisterPage</div>;
}
